<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;


class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        User::create([
            'name' => 'Mganilwa',
            'email' => 'mganilwa@gmail.com',
            'phone' => '0712345678',
            'role_id' => '1',
            'department_id' => '1',
            'password' => '$2y$10$Lga1NvvdMqd0r2eImbJ.ReBO/Jen5lPS9zbB6lMf1dD88',
            'reference' => 'ReBO/Jen5lPS9zbB6lMf1dD88',
            'reg' => 'NIT/REC/001',
        ]);
    }
}
