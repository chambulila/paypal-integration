
<?php $__env->startSection('content'); ?>
	<div class="min-h-screen flex flex-col sm:justify-center items-center pt-6 sm:pt-0 bg-gray-100">
		<div>
			<center>
				<img src="<?php echo e(asset('NIT_logoBg.png')); ?>" alt="" width="10%">
				<span class="uppercase font-bold">nit leave request management system</span>
			</center>
	</div>

		<div class="w-full sm:max-w-md mt-6 px-6 py-4 bg-white shadow-md overflow-hidden sm:rounded-lg">
			<!-- Validation Errors -->
			<?php if($errors->any()): ?>
				<div class="mb-4">
					<div class="font-medium text-red-600">
						<?php echo e(__('Whoops! Something went wrong.')); ?>

					</div>

					<ul class="mt-3 list-disc list-inside text-sm text-red-600">
						<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li><?php echo e($error); ?></li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</ul>
				</div>
			<?php endif; ?>

			<form method="POST" action="<?php echo e(route('register')); ?>">
			<?php echo csrf_field(); ?>

			<!-- Name -->
				<div>
					<label for="name" class="block font-medium text-sm text-gray-700">
						<?php echo e(__('Name')); ?>

					</label>

					<input id="name" name="name" type="text" class="block mt-1 w-full rounded-md shadow-sm border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50" value="<?php echo e(old('name')); ?>" required autofocus>
				</div>

					<!-- Phone -->
					<div>
						<label for="name" class="block font-medium text-sm text-gray-700">
							<?php echo e(__('Phone')); ?>

						</label>
	
						<input id="phone" name="phone" type="number" class="block mt-1 w-full rounded-md shadow-sm border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50" value="<?php echo e(old('name')); ?>" required autofocus>
					</div>
				<!-- Email Address -->
				<div class="mt-4">
					<label for="email" class="block font-medium text-sm text-gray-700">
						<?php echo e(__('Email')); ?>

					</label>

					<input id="email" name="email" type="email" class="block mt-1 w-full rounded-md shadow-sm border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50" value="<?php echo e(old('email')); ?>" required>
				</div>
				<div class="form-group">
				  <label for="">Department</label>
				  <select class="block mt-1 w-full rounded-md shadow-sm border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50" name="department_id" >
					<option>----select---</option>
					<?php $__currentLoopData = \App\Models\Department::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value="<?php echo e($dep->id); ?>" ><?php echo e($dep->name); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				  </select>
				</div>
					<!-- Password -->
					<div class="mt-4">
						<label for="password" class="block font-medium text-sm text-gray-700">
							<?php echo e(__('Reginstation Number')); ?>

						</label>
	
						<input id="reg" name="reg" type="text" class="block mt-1 w-full rounded-md shadow-sm border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50" required>
					</div>
				<!-- Password -->
				<div class="mt-4">
					<label for="password" class="block font-medium text-sm text-gray-700">
						<?php echo e(__('Password')); ?>

					</label>

					<input id="password" name="password" type="password" class="block mt-1 w-full rounded-md shadow-sm border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50" required autocomplete="new-password">
				</div>

				<!-- Confirm Password -->
				<div class="mt-4">
					<label for="password_confirmation" class="block font-medium text-sm text-gray-700">
						<?php echo e(__('Confirm Password')); ?>

					</label>

					<input id="password_confirmation" name="password_confirmation" type="password" class="block mt-1 w-full rounded-md shadow-sm border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50" required>
				</div>

				<div class="flex items-center justify-end mt-4">
					<a class="underline text-sm text-gray-600 hover:text-gray-900" href="<?php echo e(route('login')); ?>">
						<?php echo e(__('Already registered?')); ?>

					</a>

					<button type="submit" class="ml-4 inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring ring-gray-300 disabled:opacity-25 transition ease-in-out duration-150">
						<?php echo e(__('Register')); ?>

					</button>
				</div>
			</form>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\leave\chat\resources\views/auth/register.blade.php ENDPATH**/ ?>