<template>

</template>

<script>
import { Link } from '@inertiajs/vue3';
import VueFeather from 'vue-feather';

export default {
    components: { Link, VueFeather },
};

</script>